

clear all
close all

addpath(genpath('../../2018_RBIG_IT_measures/'))
save_data_fold = './DATA/';

mkdir([save_data_fold 'KLD_ts_vs_gaus/'])
%% parameters
NNs = [500 1000 5000 10000 30000 50000];
DDs = [2 3 10 50 100];
NU1s = [2 4 7];
nu1 = 100;

Nsamples_ori = 500000;


for ind_d = 1:length(DDs)
    for ind_nu1 = 1:length(NU1s)
        for ind_Ns = 1:length(NNs)
            for ind_tryal = 1:5
                
                Nsamples = NNs(ind_Ns);
                dim_ori = DDs(ind_d);
                
                CX = eye(dim_ori);
                nu2 = NU1s(ind_nu1);
                
                X = mvtrnd_val(CX, nu1, Nsamples,ind_tryal);
                Y = mvtrnd_val(CX, nu2, Nsamples,ind_tryal);
                
                % 2018 Villa page 5
                K1 = gamma((nu1+dim_ori)/2)/(gamma(nu1/2)*sqrt((pi*nu1)^dim_ori));
                K2 = gamma((nu2+dim_ori)/2)/(gamma(nu2/2)*sqrt((pi*nu2)^dim_ori));
                
                INT_1 = psi((nu1+dim_ori)/2) - psi(nu1/2);
                
                t = linspace(10^-10,10^6,10^8);
                delta_t = t(3)-t(2);
                fff = (1+t./nu1).^(-(nu1+dim_ori)/2) .* t.^(dim_ori/2-1) .* log(1+t/nu2);
                INT_2 = K1 * (pi^(dim_ori/2))/gamma(dim_ori/2) * sum(fff*delta_t);
                
                KLD_ori_nats = log(K1/K2) - (nu1+dim_ori)/2 * INT_1 + (nu2+dim_ori)/2 * INT_2;
                
                RES(ind_Ns,ind_d,ind_nu1,ind_tryal).KLD_ori = KLD_ori_nats;%/log(2);
                
                
                X = X(1:Nsamples,:);
                Y = Y(1:Nsamples,:);
                
                save([save_data_fold 'KLD_ts_vs_gaus/DATA_KLD_ts_vs_gaus_nd_' num2str(dim_ori) '_Ns_' num2str(Nsamples) '_tryal_' num2str(ind_tryal) '_mu_' num2str(ind_nu1) ]...
                ,'KLD_ori_nats','X','Y')
            
                [ind_d,ind_nu1,ind_Ns,ind_tryal]

            end
        end
    end
end

