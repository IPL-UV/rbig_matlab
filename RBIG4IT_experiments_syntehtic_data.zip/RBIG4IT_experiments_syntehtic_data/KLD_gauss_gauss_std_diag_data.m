

clear all
close all

save_data_fold = './DATA/';

%% gauss
NNs = [500 1000 5000 10000 30000 50000];
DDs = [2 3 10 50 100];
MUs = [0.5 0.75 0.9];

Nsamples_ori = 500000;


for ind_d = 1:length(DDs)
    for ind_mu = 1:length(MUs)
        for ind_Ns = 1:length(NNs)
            for ind_tryal = 1:5
                
                Nsamples = NNs(ind_Ns);
                dim_ori = DDs(ind_d);
               
                
                rand('seed',ind_tryal+100)
                A = rand(dim_ori);
                C2 = A*A';
                C2 = C2/max(C2(:));
                
                CX = eye(dim_ori);
                CY = CX + MUs(ind_mu)*C2;
                CY = CY./max(CY(:));
                
                muX = zeros(1,dim_ori);
                muY = zeros(1,dim_ori);
                
                randn('seed',ind_tryal)
                X = mvnrnd(muX,CX,Nsamples_ori);
                randn('seed',ind_tryal+100)
                Y = mvnrnd(muY,CY,Nsamples_ori);
                
                KLD_ori_nats = 0.5*[(muY-muX)*inv(CY)*(muY-muX)' + trace(inv(CY)*CX) - log(det(CX)/det(CY)) - dim_ori];
                RES(ind_Ns,ind_d,ind_mu,ind_tryal).KLD_ori = KLD_ori_nats;
                
                X = X(1:Nsamples,:);
                Y = Y(1:Nsamples,:);
                
                 save([save_data_fold 'KLD_gaus_vs_gaus/DATA_KLD_gaus_vs_gaus_std_diag_nd_' num2str(dim_ori) '_Ns_' num2str(Nsamples) '_tryal_' num2str(ind_tryal) '_mu_' num2str(ind_mu) ]...
                ,'KLD_ori_nats','X','Y')
            
            
                [ind_d,ind_mu,ind_Ns,ind_tryal]
            end
        end
    end
end

