

clear all
close all

addpath(genpath('/media/disk/vista/Papers/2018_RBIG_IT_measures/'))
addpath(genpath('/media/disk/users/valero/FUMADAS/2017_RBIG/'))

save_data_fold = '/media/disk/vista/Papers/2018_RBIG_IT_measures/reproducible_results/DATA/';
save_res_fold = '/media/disk/vista/Papers/2018_RBIG_IT_measures/reproducible_results/RES/';

%% t-student
NNs = [500 1000 5000 10000 30000 50000];
DDs = [2 3 10 50 100];
NUs = [3 5 20];

RES(1,1,1).NNs = NNs;
RES(1,1,1).DDs = DDs;
RES(1,1,1).NUs = NUs;

for ind_d = 5%1:length(DDs)
    for ind_nu = 1:length(NUs)
        for ind_Ns = 1:length(NNs)
            
            for ind_tryal = 1:5
                
                Nsamples = NNs(ind_Ns);
                dim_ori = DDs(ind_d);
                nu_ori = NUs(ind_nu);
                
                load([save_data_fold 'TC_tstu/DATA_TC_tstu_nd_' num2str(dim_ori) '_Ns_' num2str(Nsamples) ...
                    '_tryal_' num2str(ind_tryal) '_nu_' num2str(ind_nu) ])
                
                %% ORIGINAL
                
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).TC_ori = TC_ori_nats;
                
                %% SZABO entropy estimators
                if dim_ori<=10
                    tic
                    RES(ind_Ns,ind_d,ind_nu,ind_tryal).TC_Shannon_AP = muting_val(dat);
                    RES(ind_Ns,ind_d,ind_nu,ind_tryal).t_TC_Shannon_AP = toc;
                end
                
                %% SZABO
                tic
                cost_name = 'Shannon_kNN_k';      %d>=1
                co = H_initialization(cost_name,1);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).TC_szabo_kNN_k = IShannon_HShannon_estimation_val(dat',co);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).t_TC_szabo_kNN_k = toc;
                
                %             % Shannon_KDP
                tic
                cost_name = 'Shannon_KDP';      %d>=1
                co = H_initialization(cost_name,1);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).TC_szabo_KDP = IShannon_HShannon_estimation_val(dat',co);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).t_TC_szabo_KDP = toc;
                
                % Shannon_expF
                tic
                cost_name = 'Shannon_expF';      %d>=1
                co = H_initialization(cost_name,1);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).TC_szabo_expF = IShannon_HShannon_estimation_val(dat',co);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).t_TC_szabo_expF = toc;
                
                % Shannon_vME
                tic
                cost_name = 'Shannon_vME';      %d>=1
                co = H_initialization(cost_name,1);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).TC_szabo_vME = IShannon_HShannon_estimation_val(dat',co);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).t_TC_szabo_vME = toc;
                
                % ensemble
                tic
                cost_name = 'ensemble';      %d>=1
                co = H_initialization(cost_name,1);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).TC_szabo_ensemble = IShannon_HShannon_estimation_val(dat',co);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).t_TC_szabo_ensemble = toc;
                
                %% RBIG
                t1 = cputime;
                
                TC_rbig = RBIG_TC(dat');
                
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).t_rbig = t1-cputime;
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).TC_rbig_nats = TC_rbig*log(2);
                
                %% ORIGINAL
                
                %RES(ind_Ns,ind_d,ind_nu,ind_tryal).TC_ori = mvt_TC_val(size(dat,2),nu_ori,C_ori);
                
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).TC_ori = TC_ori_nats
                
                %% SAVE
                save([save_res_fold 'RES_TC_tstu'],'RES')
                
                [ind_Ns,ind_d,ind_nu]
            end
        end
    end
end

