

clear all
close all

addpath(genpath('/media/disk/vista/Papers/2018_RBIG_IT_measures/tdistfit-master/'))
addpath(genpath('/media/disk/users/valero/FUMADAS/2017_RBIG/'))

print_fold = '/media/disk/erc/papers/2018_RBIG_IT_measures/2018_RBIG_IT_measures/reproducible_results/FIGS/TC_tstu/';
save_res_fold = '/media/disk/erc/papers/2018_RBIG_IT_measures/2018_RBIG_IT_measures/reproducible_results/RES/';

%% FIGURETES

fontname = 'Arial';
fontsize = 18;
fontunits = 'points';
set(0,'DefaultAxesFontName',fontname,'DefaultAxesFontSize',fontsize,'DefaultAxesFontUnits',fontunits,...
    'DefaultTextFontName',fontname,'DefaultTextFontSize',fontsize,'DefaultTextFontUnits',fontunits,...
    'DefaultLineLineWidth',3,'DefaultLineMarkerSize',8,'DefaultLineColor',[0 0 0]);

%% Student-t

NNs = [500 1000 5000 10000 30000 50000];
DDs = [2 3 10 50 100];
NUs = [3 5 20];


%%

load([save_res_fold 'RES_TC_tstu'],'RES')

for ind_nu = 1:length(NUs)
    
    figure
    iii=1;
    alfa = 0.15;
    SS = 0.5;
    AX_MY = 1.5;
    %for ind_Ns = 1:length(NNs)
    for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
        subplot(1,5,iii)
        TC_ori = []; TC_rbig_nats = []; TC_szabo_kNN_k = []; TC_Shannon_AP = [];
        TC_szabo_KDP = []; TC_szabo_expF = []; TC_szabo_vME = []; TC_szabo_ensemble = [];
        for nnn = 1:5%size(RES,3)
            TC_ori(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_ori);
            TC_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_rbig_nats);
            if DDs(ind_d) <=5
                TC_Shannon_AP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_Shannon_AP);
            end
            TC_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_kNN_k);
            TC_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_KDP);
            TC_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_expF);
            TC_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_vME);
            TC_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_ensemble);
        end
        
        hold on
        AA = abs(abs(TC_rbig_nats-TC_ori)./TC_ori);
        plot(NNs(indi),mean(AA,2),'r')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        if DDs(ind_d) <=5
            AA = abs(abs(TC_Shannon_AP-TC_ori)./TC_ori);
            hold on
            plot(NNs(indi),mean(AA,2),'g')
            xx = [NNs(indi) flip(NNs(indi))];
            yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
            fill(xx,yy,'g', 'LineStyle', 'None', 'FaceAlpha', alfa)
        end
        AA = abs(abs(TC_szabo_kNN_k-TC_ori)./TC_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'k')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = abs(abs(TC_szabo_KDP-TC_ori)./TC_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'b')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = abs(abs(TC_szabo_expF-TC_ori)./TC_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'y')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = abs(abs(TC_szabo_vME-TC_ori)./TC_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'m')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = abs(abs(TC_szabo_ensemble-TC_ori)./TC_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'c')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        grid
        axis([0 max(NNs) 0 AX_MY])
        iii = iii+1;
    end
end

% PRINT

for ind_nu = 1:length(NUs)
    alfa = 0.15;
    SS = 0.5;
    AX_MY = 150;
    %for ind_Ns = 1:length(NNs)
    for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
        figure
        
       TC_ori = []; TC_rbig_nats = []; TC_szabo_kNN_k = []; TC_Shannon_AP = [];
        TC_szabo_KDP = []; TC_szabo_expF = []; TC_szabo_vME = []; TC_szabo_ensemble = [];
        for nnn = 1:5%size(RES,3)
            TC_ori(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_ori);
            TC_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_rbig_nats);
            if DDs(ind_d) <=5
                TC_Shannon_AP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_Shannon_AP);
            end
            TC_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_kNN_k);
            TC_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_KDP);
            TC_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_expF);
            TC_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_vME);
            TC_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_ensemble);
        end
        
        hold on
        AA = 100*abs(abs(TC_rbig_nats-TC_ori)./TC_ori);
        plot(NNs(indi),mean(AA,2),'r')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        if DDs(ind_d) <=5
            AA = 100*abs(abs(TC_Shannon_AP-TC_ori)./TC_ori);
            hold on
            plot(NNs(indi),mean(AA,2),'g')
            xx = [NNs(indi) flip(NNs(indi))];
            yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
            fill(xx,yy,'g', 'LineStyle', 'None', 'FaceAlpha', alfa)
        end
        
        AA = 100*abs(abs(TC_szabo_kNN_k-TC_ori)./TC_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'k')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(TC_szabo_KDP-TC_ori)./TC_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'b')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(TC_szabo_expF-TC_ori)./TC_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'y')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(TC_szabo_vME-TC_ori)./TC_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'m')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(TC_szabo_ensemble-TC_ori)./TC_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'c')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        grid
        axis([0 max(NNs) 0 AX_MY])
        
        xlabel('# samples')
        ylabel('% error')
        print('-deps2c',[print_fold 'FIG_TC_stud_t_' num2str(NUs(ind_nu)) '_DIM_' num2str(DDs(ind_d))])
    end
end
    
% PRINT log

for ind_nu = 1:length(NUs)
    alfa = 0.15;
    SS = 0.5;
    AX_MY = 50;
    %for ind_Ns = 1:length(NNs)
    for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
       fig= figure
        axes1 = axes('Parent',fig);
        
       TC_ori = []; TC_rbig_nats = []; TC_szabo_kNN_k = []; TC_Shannon_AP = [];
        TC_szabo_KDP = []; TC_szabo_expF = []; TC_szabo_vME = []; TC_szabo_ensemble = [];
        for nnn = 1:5%size(RES,3)
            TC_ori(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_ori);
            TC_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_rbig_nats);
            if DDs(ind_d) <=5
                TC_Shannon_AP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_Shannon_AP);
            end
            TC_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_kNN_k);
            TC_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_KDP);
            TC_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_expF);
            TC_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_vME);
            TC_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_ensemble);
        end
        
        hold on
        AA = 100*abs(abs(TC_rbig_nats-TC_ori)./TC_ori);
        plot(NNs(indi),mean(AA,2),'r')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        if DDs(ind_d) <=5
            AA = 100*abs(abs(TC_Shannon_AP-TC_ori)./TC_ori);
            hold on
            plot(NNs(indi),mean(AA,2),'g')
            xx = [NNs(indi) flip(NNs(indi))];
            yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
            fill(xx,yy,'g', 'LineStyle', 'None', 'FaceAlpha', alfa)
        end
        
        AA = 100*abs(abs(TC_szabo_kNN_k-TC_ori)./TC_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'k')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(TC_szabo_KDP-TC_ori)./TC_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'b')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(TC_szabo_expF-TC_ori)./TC_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'y')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(TC_szabo_vME-TC_ori)./TC_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'m')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(TC_szabo_ensemble-TC_ori)./TC_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'c')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        grid
        axis([0 max(NNs) 0 AX_MY])
        
        xlabel('# samples')
        ylabel('% error')
        set(axes1,'XScale','log');
        print('-deps2c',[print_fold 'FIG_TC_stud_t_log_' num2str(NUs(ind_nu)) '_DIM_' num2str(DDs(ind_d))])
    end
end
    
% TABLA

A = [];
for ind_nu = 1:length(NUs)
    
  
    for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
       
        TC_ori = []; TC_rbig_nats = []; TC_szabo_kNN_k = []; TC_Shannon_AP = [];
        TC_szabo_KDP = []; TC_szabo_expF = []; TC_szabo_vME = []; TC_szabo_ensemble = [];
        for nnn = 1:5%size(RES,3)
            TC_ori(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_ori);
            TC_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_rbig_nats);
            if DDs(ind_d) <=5
                TC_Shannon_AP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_Shannon_AP);
            end
            TC_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_kNN_k);
            TC_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_KDP);
            TC_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_expF);
            TC_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_vME);
            TC_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).TC_szabo_ensemble);
        end
        
        ind_n = 4;
        
        aux = abs(TC_rbig_nats-TC_ori)./TC_ori;
        M(ind_d,1,:) = aux(ind_n,:);
        
        aux = abs(TC_szabo_kNN_k-TC_ori)./TC_ori;
        M(ind_d,2,:) = aux(ind_n,:);
        
        aux = abs(TC_szabo_KDP-TC_ori)./TC_ori;
        M(ind_d,3,:) = aux(ind_n,:);
        
        aux = abs(TC_szabo_expF-TC_ori)./TC_ori;
        M(ind_d,4,:) = aux(ind_n,:);
        
        aux = abs(TC_szabo_vME-TC_ori)./TC_ori;
        M(ind_d,5,:) = aux(ind_n,:);
        
        aux = abs(TC_szabo_ensemble-TC_ori)./TC_ori;
        M(ind_d,6,:) = aux(ind_n,:);

    end
    
    A(:,:,ind_nu) = quant(mean(M,3),0.0001);
    
end

A(:,:,1)*100


%% time

for ind_nu = 1:length(NUs)
    figure
    iii=1;
    alfa = 0.15;
    SS = 1;
    %for ind_Ns = 1:length(NNs)
    for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
        subplot(1,5,iii)
        TC_rbig_nats = []; TC_szabo_kNN_k = []; TC_Shannon_AP = [];
        TC_szabo_KDP = []; TC_szabo_expF = []; TC_szabo_vME = []; TC_szabo_ensemble = [];
        for nnn = 1:size(RES,4)
            TC_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_rbig);
            if DDs(ind_d) <=5
                TC_Shannon_AP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_TC_Shannon_AP);
            end
            TC_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_TC_szabo_kNN_k);
            TC_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_TC_szabo_KDP);
            TC_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_TC_szabo_expF);
            TC_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_TC_szabo_vME);
            TC_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_TC_szabo_ensemble);
        end
        
        hold on
        AA = (abs(TC_rbig_nats));
        plot(NNs(indi),mean(AA,2),'r--')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        if DDs(ind_d) <=5
            AA = (abs(TC_Shannon_AP));
            hold on
            plot(NNs(indi),mean(AA,2),'g-')
            xx = [NNs(indi) flip(NNs(indi))];
            yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
            fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        end
        
        AA = (abs(TC_szabo_kNN_k));
        hold on
        plot(NNs(indi),mean(AA,2),'k-')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(TC_szabo_KDP));
        hold on
        plot(NNs(indi),mean(AA,2),'bo--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(TC_szabo_expF));
        hold on
        plot(NNs(indi),mean(AA,2),'ys:')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(TC_szabo_vME));
        hold on
        plot(NNs(indi),mean(AA,2),'m--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(TC_szabo_ensemble));
        hold on
        plot(NNs(indi),mean(AA,2),'c:')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        set(gca, 'YScale', 'log')
        
        grid
        axis tight
        iii = iii+1;
    end
end

% PRINT time

for ind_nu = 1:length(NUs)
    alfa = 0.15;
    SS = 1;
    %for ind_Ns = 1:length(NNs)
    for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
        figure
        TC_rbig_nats = []; TC_szabo_kNN_k = []; TC_Shannon_AP = [];
        TC_szabo_KDP = []; TC_szabo_expF = []; TC_szabo_vME = []; TC_szabo_ensemble = [];
        for nnn = 1:size(RES,4)
            TC_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_rbig);
            if DDs(ind_d) <=5
                TC_Shannon_AP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_TC_Shannon_AP);
            end
            TC_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_TC_szabo_kNN_k);
            TC_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_TC_szabo_KDP);
            TC_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_TC_szabo_expF);
            TC_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_TC_szabo_vME);
            TC_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_TC_szabo_ensemble);
        end
        
        hold on
        AA = (abs(TC_rbig_nats));
        plot(NNs(indi),mean(AA,2),'r--')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
          
        if DDs(ind_d) <=5
            AA = (abs(TC_Shannon_AP));
            hold on
            plot(NNs(indi),mean(AA,2),'g-')
            xx = [NNs(indi) flip(NNs(indi))];
            yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
            fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        end
        
        AA = (abs(TC_szabo_kNN_k));
        hold on
        plot(NNs(indi),mean(AA,2),'k--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(TC_szabo_KDP));
        hold on
        plot(NNs(indi),mean(AA,2),'b--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(TC_szabo_expF));
        hold on
        plot(NNs(indi),mean(AA,2),'y--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(TC_szabo_vME));
        hold on
        plot(NNs(indi),mean(AA,2),'m--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(TC_szabo_ensemble));
        hold on
        plot(NNs(indi),mean(AA,2),'c--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        set(gca, 'YScale', 'log')
        
        xlabel('# samples')
        ylabel('computational time (s)')
        
        grid
        axis tight
        print('-deps2c',[print_fold 'FIG_TC_t_stud_t_' num2str(NUs(ind_nu)) '_DIM_' num2str(DDs(ind_d))])
    end
end

