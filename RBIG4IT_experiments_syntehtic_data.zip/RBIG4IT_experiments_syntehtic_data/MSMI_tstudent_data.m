

clear all
close all

addpath(genpath('/media/disk/vista/Papers/2018_RBIG_IT_measures/'))
addpath(genpath('/media/disk/users/valero/FUMADAS/2017_RBIG/'))

save_data_fold = '/media/disk/vista/Papers/2018_RBIG_IT_measures/reproducible_results/DATA/';

%% t-student
NNs = [500 1000 5000 10000 30000 50000];
DDs = [2 3 10 50 100];
NUs = [3 5 20];

RES(1,1,1).NNs = NNs;
RES(1,1,1).DDs = DDs;
RES(1,1,1).NUs = NUs;


for ind_d = 1:length(DDs)
    for ind_nu = 1:length(NUs)
        for ind_Ns = 1:length(NNs)
            for ind_tryal = 1:5
                
                Nsamples = NNs(ind_Ns);
                dim_ori = DDs(ind_d);
                nu_ori = NUs(ind_nu);
                
                rand('seed',ind_tryal)
                A = rand(2*dim_ori);
                A = A*A';
                COV_ori = 10*eye(2*dim_ori)+A;
                
                C_ori = corrcov(COV_ori);
                dat_all = mvtrnd_val(C_ori, nu_ori, Nsamples,ind_tryal);
                
                X = dat_all(:,1:dim_ori);
                Y = dat_all(:,dim_ori+1:2*dim_ori);
                
                CX = C_ori(1:dim_ori,1:dim_ori);
                CY = C_ori(dim_ori+1:2*dim_ori,dim_ori+1:2*dim_ori);
                
                H_X = mvt_entr_val(dim_ori,nu_ori,CX);
                H_Y = mvt_entr_val(dim_ori,nu_ori,CY);
                H = mvt_entr_val(2*dim_ori,nu_ori,C_ori);
                
                
                MI_ori = H_X + H_Y - H;
                
                X = X(1:Nsamples,:);
                Y = Y(1:Nsamples,:);
                dat = dat_all(1:Nsamples,:);
                
                MI_ori_nats = MI_ori*log(2);
                
                save([save_data_fold 'MI_tstu/DATA_MI_tstu_nd_' num2str(dim_ori) '_Ns_' num2str(Nsamples) ...
                    '_tryal_' num2str(ind_tryal) '_nu_' num2str(ind_nu) ],'MI_ori_nats','dat','X','Y')
                
            end
        end
    end
    [ind_d ind_nu ind_Ns]
end


