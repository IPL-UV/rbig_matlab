

clear all
close all

addpath(genpath('/media/disk/vista/Papers/2018_RBIG_IT_measures/'))
addpath(genpath('/media/disk/users/valero/FUMADAS/2017_RBIG/'))

save_data_fold = '/media/disk/vista/Papers/2018_RBIG_IT_measures/reproducible_results/DATA/';

%% linear
NNs = [500 1000 5000 10000 30000 50000];
DDs = [2 3 10 50 100];

Nsamples_ori = 500000;

for ind_d = 1:length(DDs)
    for ind_Ns = 1:length(NNs)
        for ind_tryal = 1:5
            
           Nsamples = NNs(ind_Ns);
            dim_ori = DDs(ind_d);
           
            randn('seed',ind_tryal);
            dat_ori = randn(Nsamples_ori,dim_ori);
            
            rand('seed',ind_tryal);
            rrr = rand(1,dim_ori);
            for n=1:dim_ori
                exp = rrr(n)*2+0.5;
                dat_ori(:,n) = sign(dat_ori(:,n)).*abs(dat_ori(:,n)).^exp;
                %figure,hist(dat_ori(:,n),1001)
            end
            
            rand('seed',ind_tryal+100);
            A = rand(dim_ori);
            dat = dat_ori*A;
            
            hx = [];
            for n=1:size(dat_ori,2)
                Raux = linspace(min(dat_ori(:,n)),max(dat_ori(:,n)),sqrt(size(dat_ori,1))+1);
                R = diff(Raux)/2+Raux(1:end-1);
                p = histcounts(dat_ori(:,n),Raux);
                delta = R(3)-R(2);
                
                % mle estimator with miller-maddow correction
                c = 0.5 * (sum(p>0)-1)/sum(p);  % miller maddow correction
                p = p/sum(p);               % empirical estimate of the distribution
                idx = p~=0;
                H = -sum(p(idx).*log2(p(idx))) + c;     % plug-in estimator of the entropy with correction
                hx(n) = H +log2(delta);
            end
            
            hy = [];
            for n=1:size(dat,2)
                Raux = linspace(min(dat(:,n)),max(dat(:,n)),sqrt(size(dat,1))+1);
                R = diff(Raux)/2+Raux(1:end-1);
                p = histcounts(dat(:,n),Raux);
                delta = R(3)-R(2);
                
                % mle estimator with miller-maddow correction
                c = 0.5 * (sum(p>0)-1)/sum(p);  % miller maddow correction
                p = p/sum(p);               % empirical estimate of the distribution
                idx = p~=0;
                H = -sum(p(idx).*log2(p(idx))) + c;     % plug-in estimator of the entropy with correction
                hy(n) = H +log2(delta);
            end
            
            H_ori = sum(hx) + log2(abs(det(A)));
            H_ori_nats = H_ori*log(2);
            
            dat = dat(1:Nsamples,:);
            
            save([save_data_fold 'ENTROPY_lin/DATA_ENTROPY_lin_nd_' num2str(dim_ori) '_Ns_' num2str(Nsamples) '_tryal_' num2str(ind_tryal)]...
                ,'H_ori_nats','dat')
        end
        [ind_Ns ind_d]
    end
end

