

clear all
close all

addpath(genpath('../../2018_RBIG_IT_measures/'))

save_data_fold = './DATA/';
save_res_fold = './RES/';
print_fold = './FIGS/KLD_gauss_vs_ts/';
mkdir(print_fold)

%% FIGURETES

fontname = 'Arial';
fontsize = 18;
fontunits = 'points';
set(0,'DefaultAxesFontName',fontname,'DefaultAxesFontSize',fontsize,'DefaultAxesFontUnits',fontunits,...
    'DefaultTextFontName',fontname,'DefaultTextFontSize',fontsize,'DefaultTextFontUnits',fontunits,...
    'DefaultLineLineWidth',3,'DefaultLineMarkerSize',8,'DefaultLineColor',[0 0 0]);

%% 
NNs = [500 1000 5000 10000 30000 50000];
DDs = [2 3 10 50 100];
NUs = [2 4 7];

%%

load([save_res_fold 'RES_KLD_ts_vs_gauss'],'RES')

for ind_nu = 1:length(NUs)
    
    figure
    iii=1;
    alfa = 0.15;
    SS = 0.5;
    AX_MY = 1;
    %for ind_Ns = 1:length(NNs)
    for ind_d = 1:length(DDs)
 
        indi = 1:size(RES,1);
        
        subplot(2,3,iii)
        KLD_ori = []; KLD_rbig_nats = []; KLD_szabo_kNN_k = [];
        KLD_szabo_KDP = []; KLD_szabo_expF = []; KLD_szabo_vME = []; KLD_szabo_ensemble = [];
        for nnn = 1:5%size(RES,3)
          
            KLD_ori(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_ori_nats);
            KLD_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_rbig_nats);
            KLD_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_kNN_k);
            %KLD_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_KDP);
            KLD_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_szabo_expF);
            KLD_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_vME);
            %KLD_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_szabo_ensemble);
        end
        
        AA = abs(abs(KLD_rbig_nats-KLD_ori)./KLD_ori);
        plot(NNs(indi),mean(AA,2),'r')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        
        AA = abs(abs(KLD_szabo_kNN_k-KLD_ori)./KLD_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'k')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
%         AA = abs(abs(KLD_szabo_KDP-KLD_ori)./KLD_ori);
%         hold on
%         plot(NNs(indi),mean(AA,2),'b')
%         xx = [NNs(indi) flip(NNs(indi))];
%         yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
%         fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = abs(abs(KLD_szabo_expF-KLD_ori)./KLD_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'y')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = abs(abs(KLD_szabo_vME-KLD_ori)./KLD_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'m')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
%         AA = abs(abs(KLD_szabo_ensemble-KLD_ori)./KLD_ori);
%         hold on
%         plot(NNs(indi),mean(AA,2),'c')
%         xx = [NNs(indi) flip(NNs(indi))];
%         yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
%         fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        grid
        axis([0 max(NNs) 0 AX_MY])
        iii = iii+1;
    end
end

% PRINT

for ind_nu = 1:length(NUs)
    alfa = 0.15;
    SS = 0.5;
    AX_MY = 100;
    %for ind_Ns = 1:length(NNs)
    for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
        figure
        
        KLD_ori = []; KLD_rbig_nats = []; KLD_szabo_kNN_k = [];
        KLD_szabo_KDP = []; KLD_szabo_expF = []; KLD_szabo_vME = []; KLD_szabo_ensemble = [];
        for nnn = 1:5%size(RES,3)

            KLD_ori(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_ori_nats);
            KLD_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_rbig_nats);
            KLD_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_kNN_k);
            %KLD_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_KDP);
            KLD_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_szabo_expF);
            KLD_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_vME);
            %KLD_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_szabo_ensemble);
        end
        
        hold on
        AA = 100*abs(abs(KLD_rbig_nats-KLD_ori)./KLD_ori);
        plot(NNs(indi),mean(AA,2),'r')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        
        AA = 100*abs(abs(KLD_szabo_kNN_k-KLD_ori)./KLD_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'k')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
%         AA = 100*abs(abs(KLD_szabo_KDP-KLD_ori)./KLD_ori);
%         hold on
%         plot(NNs(indi),mean(AA,2),'b')
%         xx = [NNs(indi) flip(NNs(indi))];
%         yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
%         fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(KLD_szabo_expF-KLD_ori)./KLD_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'y')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(KLD_szabo_vME-KLD_ori)./KLD_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'m')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        yy(find(yy>10)) = zeros;
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
%         AA = 100*abs(abs(KLD_szabo_ensemble-KLD_ori)./KLD_ori);
%         hold on
%         plot(NNs(indi),mean(AA,2),'c')
%         xx = [NNs(indi) flip(NNs(indi))];
%         yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
%         fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        grid
        axis([0 max(NNs) 0 AX_MY])
        
        xlabel('# samples')
        ylabel('% error')
        print('-deps2c',[print_fold 'FIG_KLD_gauss_vs_ts_nu_' num2str(NUs(ind_nu)) '_DIM_' num2str(DDs(ind_d))])
    end
end
    
% PRINT LOG

for ind_nu = 1:length(NUs)
    alfa = 0.15;
    SS = 0.5;
    AX_MY = 100;
    %for ind_Ns = 1:length(NNs)
    for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
        fig= figure
        axes1 = axes('Parent',fig);
        
        KLD_ori = []; KLD_rbig_nats = []; KLD_szabo_kNN_k = [];
        KLD_szabo_KDP = []; KLD_szabo_expF = []; KLD_szabo_vME = []; KLD_szabo_ensemble = [];
        for nnn = 1:5%size(RES,3)

            KLD_ori(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_ori_nats);
            KLD_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_rbig_nats);
            KLD_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_kNN_k);
            %KLD_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_KDP);
            KLD_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_szabo_expF);
            KLD_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_vME);
            %KLD_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_szabo_ensemble);
        end
        
        hold on
        AA = 100*abs(abs(KLD_rbig_nats-KLD_ori)./KLD_ori);
        plot(NNs(indi),mean(AA,2),'r')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        
        AA = 100*abs(abs(KLD_szabo_kNN_k-KLD_ori)./KLD_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'k')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
%         AA = 100*abs(abs(KLD_szabo_KDP-KLD_ori)./KLD_ori);
%         hold on
%         plot(NNs(indi),mean(AA,2),'b')
%         xx = [NNs(indi) flip(NNs(indi))];
%         yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
%         fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(KLD_szabo_expF-KLD_ori)./KLD_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'y')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(KLD_szabo_vME-KLD_ori)./KLD_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'m')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        yy(find(yy>10)) = zeros;
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
%         AA = 100*abs(abs(KLD_szabo_ensemble-KLD_ori)./KLD_ori);
%         hold on
%         plot(NNs(indi),mean(AA,2),'c')
%         xx = [NNs(indi) flip(NNs(indi))];
%         yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
%         fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        grid
        axis([0 max(NNs) 0 AX_MY])
        
        xlabel('# samples')
        ylabel('% error')
        set(axes1,'XScale','log');
        print('-deps2c',[print_fold 'FIG_KLD_gauss_vs_ts_log_nu_' num2str(NUs(ind_nu)) '_DIM_' num2str(DDs(ind_d))])
    end
end
    
% TABLE
A= [];
for ind_nu = 1:length(NUs)
    M = [];
    for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
      KLD_ori = []; KLD_rbig_nats = []; KLD_szabo_kNN_k = [];
        KLD_szabo_KDP = []; KLD_szabo_expF = []; KLD_szabo_vME = []; KLD_szabo_ensemble = [];
        for nnn = 1:5%size(RES,3)
            KLD_ori(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_ori_nats);
            KLD_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_rbig_nats);
            KLD_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_kNN_k);
            %KLD_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_KDP);
            KLD_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_szabo_expF);
            KLD_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_vME);
            %KLD_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).KLD_szabo_ensemble);
        end
        
        
        ind_n = 4;
        
        aux = abs(KLD_rbig_nats-KLD_ori)./KLD_ori;
        M(ind_d,1,:) = aux(ind_n,:);
        
        aux = abs(KLD_szabo_kNN_k-KLD_ori)./KLD_ori;
        M(ind_d,2,:) = aux(ind_n,:);

        aux = abs(KLD_szabo_expF-KLD_ori)./KLD_ori;
        M(ind_d,3,:) = aux(ind_n,:);
        
        aux = abs(KLD_szabo_vME-KLD_ori)./KLD_ori;
        M(ind_d,4,:) = aux(ind_n,:);
        
%         aux = abs(KLD_szabo_ensemble-KLD_ori)./KLD_ori;
%         M(ind_d,6,:) = aux(ind_n,:);
        
    end
      A(:,:,ind_nu) = quant(mean(M,3),0.0001);
end

A(:,:,1)*100
A(:,:,2)*100
A(:,:,3)*100

%% time

for ind_nu = 1:length(NUs)
    figure
    iii=1;
    alfa = 0.15;
    SS = 1;
    %for ind_Ns = 1:length(NNs)
    for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
        subplot(1,5,iii)
        t_KLD_rbig_nats = []; t_KLD_szabo_kNN_k = [];
        t_KLD_szabo_KDP = []; t_KLD_szabo_expF = []; t_KLD_szabo_vME = []; t_KLD_szabo_ensemble = [];
        for nnn = 1:size(RES,4)
            KLD_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_KLD_rbig);
            KLD_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_KLD_szabo_kNN_k);
            KLD_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_KLD_szabo_KDP);
            KLD_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_KLD_szabo_expF);
            KLD_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_KLD_szabo_vME);
            KLD_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_KLD_szabo_ensemble);
        end
        
        hold on
        AA = (abs(KLD_rbig_nats));
        plot(NNs(indi),mean(AA,2),'r--')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        
        AA = (abs(KLD_szabo_kNN_k));
        hold on
        plot(NNs(indi),mean(AA,2),'k-')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(KLD_szabo_KDP));
        hold on
        plot(NNs(indi),mean(AA,2),'bo--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(KLD_szabo_expF));
        hold on
        plot(NNs(indi),mean(AA,2),'ys:')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(KLD_szabo_vME));
        hold on
        plot(NNs(indi),mean(AA,2),'m--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(KLD_szabo_ensemble));
        hold on
        plot(NNs(indi),mean(AA,2),'c:')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        set(gca, 'YScale', 'log')
        
        grid
        axis tight
        iii = iii+1;
    end
end

% PRINT time

for ind_nu = 1:length(NUs)
    alfa = 0.15;
    SS = 1;
    %for ind_Ns = 1:length(NNs)
    for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
        figure
        t_KLD_rbig_nats = []; t_KLD_szabo_kNN_k = [];
        t_KLD_szabo_KDP = []; t_KLD_szabo_expF = []; t_KLD_szabo_vME = []; t_KLD_szabo_ensemble = [];
        for nnn = 1:size(RES,4)
            KLD_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_KLD_rbig);
            KLD_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_KLD_szabo_kNN_k);
            KLD_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_KLD_szabo_KDP);
            KLD_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_KLD_szabo_expF);
            KLD_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_KLD_szabo_vME);
            KLD_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,ind_nu,nnn).t_KLD_szabo_ensemble);
        end
        
        hold on
        AA = (abs(KLD_rbig_nats));
        plot(NNs(indi),mean(AA,2),'r--')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        
        AA = (abs(KLD_szabo_kNN_k));
        hold on
        plot(NNs(indi),mean(AA,2),'k--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(KLD_szabo_KDP));
        hold on
        plot(NNs(indi),mean(AA,2),'b--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(KLD_szabo_expF));
        hold on
        plot(NNs(indi),mean(AA,2),'y--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(KLD_szabo_vME));
        hold on
        plot(NNs(indi),mean(AA,2),'m--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(KLD_szabo_ensemble));
        hold on
        plot(NNs(indi),mean(AA,2),'c--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        set(gca, 'YScale', 'log')
        
        xlabel('# samples')
        ylabel('computational time (s)')
        
        grid
        axis tight
        print('-deps2c',[print_fold 'FIG_entr_t_stud_t_' num2str(NUs(ind_nu)) '_DIM_' num2str(DDs(ind_d))])
    end
end


% 
% 
% %% gauss
% NNs = [500 1000 5000 10000 30000 50000];
% DDs = [2 3 10 50 100];
% MUs = [0.5 0.75 0.9];
% 
% Nsamples_ori = 500000;
% 
% 
% load([save_res_fold 'RES_KLD_gauss_gauss_mean'],'RES')
% 
% 
% for ind_d = 1:length(DDs)
%     
%     for ind_mu = 1:length(MUs)
%         indi = 1:size(RES(:,ind_d,ind_mu,1),1);
%         
%         KLD_ori = []; KLD_rbig_nats = []; KLD_kNN_k = [];
%         KLD_szabo_KDP = []; KLD_szabo_expF = []; KLD_vME = []; KLD_kNN_kiTi = [];
%         for nnn = 1:size(RES,4)
%             KLD_ori(:,nnn) = cat(1,RES(indi,ind_d,ind_mu,nnn).KLD_ori);
%             KLD_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,ind_mu,nnn).KLD_rbig_nats);
%             KLD_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,ind_mu,nnn).KLD_kNN_k);
%             KLD_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,ind_mu,nnn).KLD_szabo_expF);
%         end
%         
%         figure
%         plot(mean(abs(KLD_ori-KLD_rbig_nats)./KLD_ori,2)','r')
%         hold on
%         plot(mean(abs(KLD_ori-KLD_kNN_k)./KLD_ori,2)','b')
%         plot(mean(abs(KLD_ori-KLD_szabo_expF)./KLD_ori,2)','y')
%     end    
% end
% 
