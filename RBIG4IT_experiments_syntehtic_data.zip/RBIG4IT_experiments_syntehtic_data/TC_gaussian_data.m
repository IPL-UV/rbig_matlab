

clear all
close all

addpath(genpath('/media/disk/vista/Papers/2018_RBIG_IT_measures/'))
addpath(genpath('/media/disk/users/valero/FUMADAS/2017_RBIG/'))

save_data_fold = '/media/disk/vista/Papers/2018_RBIG_IT_measures/reproducible_results/DATA/';

%% gauss

NNs = [500 1000 5000 10000 30000 50000];
DDs = [2 3 10 50 100];

Nsamples_ori = 500000;

RES(1,1,1).NNs = NNs;
RES(1,1,1).DDs = DDs;

for ind_d = 1:length(DDs)
    for ind_Ns = 1:length(NNs)
        
        for ind_tryal = 1:5
            
            Nsamples = NNs(ind_Ns);
            dim_ori = DDs(ind_d);
            
            randn('seed',ind_tryal);
            dat_ori = randn(Nsamples_ori,dim_ori);
            
            rand('seed',ind_tryal+100);
            A = rand(dim_ori);
            dat = dat_ori*A;
          
            C = A'*A;
            vv = diag(C);
            
            dat = dat(1:Nsamples,:);
            
            % ORIGINAL TC
            
            TC_ori_nats = sum(log(sqrt(vv))) - 0.5*log(det(C));
            
            save([save_data_fold 'TC_gaus/DATA_TC_gaus_nd_' num2str(dim_ori) '_Ns_' num2str(Nsamples) '_tryal_' num2str(ind_tryal)]...
                ,'TC_ori_nats','dat')
        end
        [ind_Ns ind_d]
    end
end

