

clear all
close all

addpath(genpath('/media/disk/vista/Papers/2018_RBIG_IT_measures/'))
addpath(genpath('/media/disk/users/valero/FUMADAS/2017_RBIG/'))

save_data_fold = '/media/disk/erc/papers/2018_RBIG_IT_measures/2018_RBIG_IT_measures/reproducible_results/DATA/';
%% gauss
NNs = [500 1000 5000 10000 30000 50000];
DDs = [2 3 10 50 100];

Nsamples_ori = 500000;

for ind_d = 1:length(DDs)
    for ind_Ns = 1:length(NNs)
        for ind_tryal = 1:5
            
            Nsamples = NNs(ind_Ns);
            dim_ori = DDs(ind_d);
           
            rand('seed',ind_tryal)
            A = rand(2*dim_ori);
            C = A*A';
            randn('seed',ind_tryal)
            dat_all = mvnrnd(zeros(1,2*dim_ori),C,Nsamples_ori);
            
            CX = C(1:dim_ori,1:dim_ori);
            CY = C(dim_ori+1:2*dim_ori,dim_ori+1:2*dim_ori);
            
%             H_X = 0.5*log(2*pi*exp(1)*abs(det(CX)));
%             H_Y = 0.5*log(2*pi*exp(1)*abs(det(CY)));
%             H = 0.5*log(2*pi*exp(1)*abs(det(C)));
             
            %H_X = 0.5*log(det(2*pi*exp(1)*CX));
            %H_Y = 0.5*log(det(2*pi*exp(1)*CY));
            %H = 0.5*log(det(2*pi*exp(1)*C));
            
            H_X = dim_ori/2 + dim_ori/2*log(2*pi) + 0.5*log(det(CX));
            H_Y = dim_ori/2 + dim_ori/2*log(2*pi) + 0.5*log(det(CY));
            H = dim_ori/2 + dim_ori/2*log(2*pi) + 0.5*log(det(C));
            
            MI_ori = H_X + H_Y - H;
            
            dat = dat_all(1:Nsamples,:);
            X = dat(:,1:dim_ori);
            Y = dat(:,dim_ori+1:2*dim_ori);
            
            MI_ori_nats = MI_ori*log(2);
            
            save([save_data_fold 'MI_gaus/DATA_MI_gaus_nd_' num2str(dim_ori) '_Ns_' num2str(Nsamples) '_tryal_' num2str(ind_tryal)]...
                ,'MI_ori_nats','dat','X','Y')
        end
        [ind_Ns ind_d]
    end
end

