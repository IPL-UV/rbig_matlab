

clear all
close all

addpath(genpath('../../2018_RBIG_IT_measures/'))

save_data_fold = './DATA/';
save_res_fold = './RES/';

%% gauss
NNs = [500 1000 5000 10000 30000 50000];
DDs = [2 3 10 50 100];
MUs = [0.2 0.4 0.6];

Nsamples_ori = 500000;


for ind_d = 1:length(DDs)
    for ind_mu = 1:length(MUs)
        for ind_Ns = 1:length(NNs)
            for ind_tryal = 1:5
                
                Nsamples = NNs(ind_Ns);
                dim_ori = DDs(ind_d);
                
                load([save_data_fold 'KLD_gaus_vs_gaus/DATA_KLD_gaus_vs_gaus_mean_nd_' num2str(dim_ori) '_Ns_' num2str(Nsamples) '_tryal_' num2str(ind_tryal) '_mu_' num2str(ind_mu) ]...
                ,'KLD_ori_nats','X','Y')
            
                %% SZABO
                % expF
                tic
                co = DKL_expF_initialization(1);
                RES(ind_Ns,ind_d,ind_mu,ind_tryal).KLD_szabo_expF = DKL_expF_estimation(X',Y',co);
                RES(ind_Ns,ind_d,ind_mu,ind_tryal).t_KLD_szabo_expF = toc;
                
                % kNN_k
                tic
                co = DKL_kNN_k_initialization(1);
                RES(ind_Ns,ind_d,ind_mu,ind_tryal).KLD_kNN_k = DKL_kNN_k_estimation(X',Y',co);
                RES(ind_Ns,ind_d,ind_mu,ind_tryal).t_KLD_kNN_k = toc;
                
                % DKL_kNN_kiTi_estimation
                tic
                co = DKL_kNN_kiTi_initialization(1);
                RES(ind_Ns,ind_d,ind_mu,ind_tryal).KLD_kNN_kiTi = DKL_kNN_kiTi_estimation(X',Y',co);
                RES(ind_Ns,ind_d,ind_mu,ind_tryal).t_KLD_kNN_kiTi = toc;
                  
                % DKL_vME_estimation
                tic
                co = DKL_vME_initialization(1);
                RES(ind_Ns,ind_d,ind_mu,ind_tryal).KLD_vME = DKL_vME_estimation(X',Y',co);
                RES(ind_Ns,ind_d,ind_mu,ind_tryal).t_KLD_vME = toc;
                
                
                %% RBIG
                tt = cputime;
                [KLD_rbig MV_g m_g] = RBIG_KLD(X',Y');
                RES(ind_Ns,ind_d,ind_mu,ind_tryal).t_KLD_rbig = cputime-tt;
                
                
                RES(ind_Ns,ind_d,ind_mu,ind_tryal).RBIG_res.KLD_rbig = KLD_rbig;
                RES(ind_Ns,ind_d,ind_mu,ind_tryal).RBIG_res.MV_g = MV_g;
                RES(ind_Ns,ind_d,ind_mu,ind_tryal).RBIG_res.m_g = m_g;
                
                KLD_rbig_nats = KLD_rbig*log(2);
                RES(ind_Ns,ind_d,ind_mu,ind_tryal).KLD_rbig_nats = KLD_rbig_nats;
                
                %% SAVING
                RES(ind_Ns,ind_d,ind_mu,ind_tryal).KLD_ori_nats = KLD_ori_nats;
                
                [ind_d,ind_mu,ind_Ns,ind_tryal]
                save([save_res_fold 'RES_KLD_gauss_vs_gauss_mean'],'RES')
            end
        end
    end
end

