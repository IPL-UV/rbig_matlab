

clear all
close all


addpath(genpath('../../2018_RBIG_IT_measures/'))

save_data_fold = './DATA/';
save_res_fold = './RES/';

%% parameters
NNs = [500 1000 5000 10000 30000 50000];
DDs = [2 3 10 50 100];
NU1s = [1 2 3];
nu1 = 8;

Nsamples_ori = 500000;


for ind_d = 1:length(DDs)
    for ind_nu1 = 1:length(NU1s)
        for ind_Ns = 1:length(NNs)
            for ind_tryal = 1:5
                
                Nsamples = NNs(ind_Ns);
                dim_ori = DDs(ind_d);
                
               load([save_data_fold 'KLD_ts_vs_ts/DATA_KLD_ts_vs_ts_nd_' num2str(dim_ori) '_Ns_' num2str(Nsamples) '_tryal_' num2str(ind_tryal) '_nu_' num2str(ind_nu1) ]...
                ,'KLD_ori_nats','X','Y')
                
                %% SZABO
                % expF
                tic
                co = DKL_expF_initialization(1);
                RES(ind_Ns,ind_d,ind_nu1,ind_tryal).KLD_szabo_expF = DKL_expF_estimation(X',Y',co);
                RES(ind_Ns,ind_d,ind_nu1,ind_tryal).t_KLD_szabo_expF = toc;
                
                % kNN_k
                tic
                co = DKL_kNN_k_initialization(1);
                RES(ind_Ns,ind_d,ind_nu1,ind_tryal).KLD_kNN_k = DKL_kNN_k_estimation(X',Y',co);
                RES(ind_Ns,ind_d,ind_nu1,ind_tryal).t_KLD_kNN_k = toc;
                
                % DKL_kNN_kiTi_estimation
                tic
                co = DKL_kNN_kiTi_initialization(1);
                RES(ind_Ns,ind_d,ind_nu1,ind_tryal).KLD_kNN_kiTi = DKL_kNN_kiTi_estimation(X',Y',co);
                RES(ind_Ns,ind_d,ind_nu1,ind_tryal).t_KLD_kNN_kiTi = toc;
                  
                % DKL_vME_estimation
                tic
                co = DKL_vME_initialization(1);
                RES(ind_Ns,ind_d,ind_nu1,ind_tryal).KLD_vME = DKL_vME_estimation(X',Y',co);
                RES(ind_Ns,ind_d,ind_nu1,ind_tryal).t_KLD_vME = toc;
                
                
                %% RBIG
                tt = cputime;
                [KLD_rbig MV_g m_g] = RBIG_KLD(X',Y');
                RES(ind_Ns,ind_d,ind_nu1,ind_tryal).t_KLD_rbig = cputime-tt;
                
                
                RES(ind_Ns,ind_d,ind_nu1,ind_tryal).RBIG_res.KLD_rbig = KLD_rbig;
                RES(ind_Ns,ind_d,ind_nu1,ind_tryal).RBIG_res.MV_g = MV_g;
                RES(ind_Ns,ind_d,ind_nu1,ind_tryal).RBIG_res.m_g = m_g;
                
                KLD_rbig_nats = KLD_rbig*log(2);
                RES(ind_Ns,ind_d,ind_nu1,ind_tryal).KLD_rbig_nats = KLD_rbig_nats;
                

                %% SAVING
                RES(ind_Ns,ind_d,ind_nu1,ind_tryal).KLD_ori_nats = KLD_ori_nats;
                
                [ind_d,ind_nu1,ind_Ns,ind_tryal]
                save([save_res_fold 'RES_KLD_ts_vs_ts'],'RES')
            end
        end
    end
end

