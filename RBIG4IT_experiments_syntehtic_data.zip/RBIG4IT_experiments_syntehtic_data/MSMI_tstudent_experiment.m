

clear all
close all

addpath(genpath('/media/disk/vista/Papers/2018_RBIG_IT_measures/'))
addpath(genpath('/media/disk/users/valero/FUMADAS/2017_RBIG/'))

save_data_fold = '/media/disk/vista/Papers/2018_RBIG_IT_measures/reproducible_results/DATA/';
save_res_fold = '/media/disk/vista/Papers/2018_RBIG_IT_measures/reproducible_results/RES/';

%% t-student
NNs = [500 1000 5000 10000 30000 50000];
DDs = [2 3 10 50 100];
NUs = [3 5 20];

RES(1,1,1).NNs = NNs;
RES(1,1,1).DDs = DDs;
RES(1,1,1).NUs = NUs;


for ind_d = 1:length(DDs)
    for ind_nu = 1:length(NUs)
        for ind_Ns = 1:length(NNs)
            for ind_tryal = 1:5
                
                Nsamples = NNs(ind_Ns);
                dim_ori = DDs(ind_d);
                nu_ori = NUs(ind_nu);
                
                load([save_data_fold 'DATA_MI_tstu_nd_' num2str(dim_ori) '_Ns_' num2str(Nsamples) ...
                    '_tryal_' num2str(ind_tryal) '_nu_' num2str(ind_nu) ])
                
                %% ORIGINAL
                
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).MI_ori = MI_ori_nats;
                
                %% SZABO
                tic
                cost_name = 'Shannon_kNN_k';      %d>=1
                co = IShannon_HShannon_initialization_val(cost_name);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).MI_szabo_kNN_k = IShannon_HShannon_estimation(dat',[dim_ori dim_ori],co);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).t_MI_szabo_kNN_k = toc;
                
                % Shannon_KDP
                cost_name = 'Shannon_KDP';      %d>=1
                co = IShannon_HShannon_initialization_val(cost_name);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).MI_szabo_KDP = IShannon_HShannon_estimation(dat',[dim_ori dim_ori],co);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).t_MI_szabo_KDP = toc;
                
                % Shannon_expF
                cost_name = 'Shannon_expF';      %d>=1
                co = IShannon_HShannon_initialization_val(cost_name);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).MI_szabo_expF = IShannon_HShannon_estimation(dat',[dim_ori dim_ori],co);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).t_MI_szabo_expF = toc;
                
                % Shannon_vME
                cost_name = 'Shannon_vME';      %d>=1
                co = IShannon_HShannon_initialization_val(cost_name);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).MI_szabo_vME = IShannon_HShannon_estimation(dat',[dim_ori dim_ori],co);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).t_MI_szabo_vME = toc;
                
                % ensemble
                cost_name = 'ensemble';      %d>=1
                co = IShannon_HShannon_initialization_val(cost_name);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).MI_szabo_ensemble = IShannon_HShannon_estimation(dat',[dim_ori dim_ori],co);
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).t_MI_szabo_ensemble = toc;
                
                
                %% RBIG
                tt = cputime
                MI_rbig = RBIG_MSMI(X',Y');
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).t_MI_rbig = cputime-tt;
                
                MI_rbig_nats = MI_rbig*log(2)
                RES(ind_Ns,ind_d,ind_nu,ind_tryal).MI_rbig_nats = MI_rbig_nats;
                
                %% SAVING
                
                save([save_res_fold 'RES_MI_tstu'],'RES')
                [ind_Ns,ind_d,ind_nu]
            end
        end
    end
end



