

clear all
close all

addpath(genpath('/media/disk/vista/Papers/2018_RBIG_IT_measures/tdistfit-master/'))
addpath(genpath('/media/disk/users/valero/FUMADAS/2017_RBIG/'))

print_fold = '/media/disk/erc/papers/2018_RBIG_IT_measures/2018_RBIG_IT_measures/reproducible_results/FIGS/ENTROPY_lin/';
save_res_fold = '/media/disk/erc/papers/2018_RBIG_IT_measures/2018_RBIG_IT_measures/reproducible_results/RES/';

%% FIGURETES

fontname = 'Arial';
fontsize = 18;
fontunits = 'points';
set(0,'DefaultAxesFontName',fontname,'DefaultAxesFontSize',fontsize,'DefaultAxesFontUnits',fontunits,...
    'DefaultTextFontName',fontname,'DefaultTextFontSize',fontsize,'DefaultTextFontUnits',fontunits,...
    'DefaultLineLineWidth',3,'DefaultLineMarkerSize',8,'DefaultLineColor',[0 0 0]);

%% linear
NNs = [500 1000 5000 10000 30000 50000];
DDs = [2 3 10 50 100];

%%

load([save_res_fold 'RES_ENTROPY_linear'],'RES')

%% %MAE

figure
iii=1;
alfa = 0.15;
SS = 0.5;
%for ind_Ns = 1:length(NNs)
for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
        subplot(2,3,iii)
        H_ori = []; H_rbig_nats = []; H_szabo_kNN_k = [];
        H_szabo_KDP = []; H_szabo_expF = []; H_szabo_vME = []; H_szabo_ensemble = [];
        for nnn = 1:5
            H_ori(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_ori);
            H_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_rbig_nats);
            H_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_kNN_k);
            H_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_KDP);
            H_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_expF);
            H_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_vME);
            H_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_ensemble);
        end
        
        AA = abs(abs(H_rbig_nats-H_ori)./H_ori);
        plot(NNs(indi),mean(AA,2),'r')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        
        AA = abs(abs(H_szabo_kNN_k-H_ori)./H_ori);
        plot(NNs(indi),mean(AA,2),'k')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = abs(abs(H_szabo_KDP-H_ori)./H_ori);
        plot(NNs(indi),mean(AA,2),'b')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = abs(abs(H_szabo_expF-H_ori)./H_ori);
        plot(NNs(indi),mean(AA,2),'y')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = abs(abs(H_szabo_vME-H_ori)./H_ori);
        plot(NNs(indi),mean(AA,2),'m')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = abs(abs(H_szabo_ensemble-H_ori)./H_ori);
        plot(NNs(indi),mean(AA,2),'c')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        grid
        axis([0 max(NNs) 0 0.2])
        iii = iii+1;
end

%% %LOG

figure
iii=1;
alfa = 0.15;
SS = 0.5;
%for ind_Ns = 1:length(NNs)
for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
        sub5 = subplot(2,3,iii)
        H_ori = []; H_rbig_nats = []; H_szabo_kNN_k = [];
        H_szabo_KDP = []; H_szabo_expF = []; H_szabo_vME = []; H_szabo_ensemble = [];
        for nnn = 1:5
            H_ori(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_ori);
            H_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_rbig_nats);
            H_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_kNN_k);
            H_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_KDP);
            H_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_expF);
            H_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_vME);
            H_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_ensemble);
        end
        
        AA = abs(abs(H_rbig_nats-H_ori)./H_ori);
        semilogx(NNs(indi),mean(AA,2),'r')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        
        AA = abs(abs(H_szabo_kNN_k-H_ori)./H_ori);
        semilogx(NNs(indi),mean(AA,2),'k')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = abs(abs(H_szabo_KDP-H_ori)./H_ori);
        semilogx(NNs(indi),mean(AA,2),'b')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = abs(abs(H_szabo_expF-H_ori)./H_ori);
        semilogx(NNs(indi),mean(AA,2),'y')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = abs(abs(H_szabo_vME-H_ori)./H_ori);
        semilogx(NNs(indi),mean(AA,2),'m')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = abs(abs(H_szabo_ensemble-H_ori)./H_ori);
        semilogx(NNs(indi),mean(AA,2),'c')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        grid
        axis([0 max(NNs) 0 0.2])
        set(sub5,'XMinorTick','on','XScale','log');
        iii = iii+1;
end

% PRINT

alfa = 0.15;
SS = 0.5;
%for ind_Ns = 1:length(NNs)
for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
        figure
        
        H_ori = []; H_rbig_nats = []; H_szabo_kNN_k = [];
        H_szabo_KDP = []; H_szabo_expF = []; H_szabo_vME = []; H_szabo_ensemble = [];
        for nnn = 1:5
            H_ori(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_ori);
            H_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_rbig_nats);
            H_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_kNN_k);
            H_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_KDP);
            H_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_expF);
            H_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_vME);
            H_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_ensemble);
        end
        
        hold on
        AA = 100*abs(abs(H_rbig_nats-H_ori)./H_ori);
        plot(NNs(indi),mean(AA,2),'r')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        
        AA = 100*abs(abs(H_szabo_kNN_k-H_ori)./H_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'k')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(H_szabo_KDP-H_ori)./H_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'b')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(H_szabo_expF-H_ori)./H_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'y')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(H_szabo_vME-H_ori)./H_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'m')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(H_szabo_ensemble-H_ori)./H_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'c')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        grid
        axis([0 max(NNs) 0 50])
        
        xlabel('# samples')
        ylabel('% error')
        print('-deps2c',[print_fold 'FIG_entr_parale_DIM_' num2str(DDs(ind_d))])
end

% PRINT LOG

alfa = 0.15;
SS = 0.5;
%for ind_Ns = 1:length(NNs)
for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
        fig= figure
        axes1 = axes('Parent',fig);
        
        H_ori = []; H_rbig_nats = []; H_szabo_kNN_k = [];
        H_szabo_KDP = []; H_szabo_expF = []; H_szabo_vME = []; H_szabo_ensemble = [];
        for nnn = 1:5
            H_ori(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_ori);
            H_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_rbig_nats);
            H_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_kNN_k);
            H_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_KDP);
            H_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_expF);
            H_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_vME);
            H_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_ensemble);
        end
        
        hold on
        AA = 100*abs(abs(H_rbig_nats-H_ori)./H_ori);
        plot(NNs(indi),mean(AA,2),'r')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        
        AA = 100*abs(abs(H_szabo_kNN_k-H_ori)./H_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'k')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(H_szabo_KDP-H_ori)./H_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'b')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(H_szabo_expF-H_ori)./H_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'y')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(H_szabo_vME-H_ori)./H_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'m')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = 100*abs(abs(H_szabo_ensemble-H_ori)./H_ori);
        hold on
        plot(NNs(indi),mean(AA,2),'c')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        grid
        axis([0 max(NNs) 0 50])
        
        xlabel('# samples')
        ylabel('% error')
        %grid(axes1,'on');
        set(axes1,'XScale','log');
        print('-deps2c',[print_fold 'FIG_entr_parale_log_DIM_' num2str(DDs(ind_d))])
end
    
% TABLA


for ind_d = 1:length(DDs)
    indi = 1:size(RES,1);
    
    
    H_ori = []; H_rbig_nats = []; H_szabo_kNN_k = [];
        H_szabo_KDP = []; H_szabo_expF = []; H_szabo_vME = []; H_szabo_ensemble = [];
        for nnn = 1:5
            H_ori(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_ori);
            H_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_rbig_nats);
            H_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_kNN_k);
            H_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_KDP);
            H_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_expF);
            H_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_vME);
            H_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,nnn).H_szabo_ensemble);
        end
    
    ind_n = 4;
    
    aux = abs(H_rbig_nats-H_ori)./H_ori;
    M(ind_d,1,:) = aux(ind_n,:);
    
    aux = abs(H_szabo_kNN_k-H_ori)./H_ori;
    M(ind_d,2,:) = aux(ind_n,:);
    
    aux = abs(H_szabo_KDP-H_ori)./H_ori;
    M(ind_d,3,:) = aux(ind_n,:);
    
    aux = abs(H_szabo_expF-H_ori)./H_ori;
    M(ind_d,4,:) = aux(ind_n,:);
    
    aux = abs(H_szabo_vME-H_ori)./H_ori;
    M(ind_d,5,:) = aux(ind_n,:);
    
    aux = abs(H_szabo_ensemble-H_ori)./H_ori;
    M(ind_d,6,:) = aux(ind_n,:);
    
end

A = quant(mean(M,3),0.001)*100


%% time

figure
iii=1;
alfa = 0.15;
SS = 1;
%for ind_Ns = 1:length(NNs)
for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
        subplot(2,3,iii)
        H_ori = []; H_rbig_nats = []; H_szabo_kNN_k = [];
        H_szabo_KDP = []; H_szabo_expF = []; H_szabo_vME = []; H_szabo_ensemble = [];
        for nnn = 1:5
            H_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,nnn).t_H_rbig);
            H_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,nnn).t_H_szabo_kNN_k);
            H_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,nnn).t_H_szabo_KDP);
            H_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,nnn).t_H_szabo_expF);
            H_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,nnn).t_H_szabo_vME);
            H_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,nnn).t_H_szabo_ensemble);
        end
        
        hold on
        AA = (abs(H_rbig_nats));
        plot(NNs(indi),mean(AA,2),'r--')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        
        AA = (abs(H_szabo_kNN_k));
        hold on
        plot(NNs(indi),mean(AA,2),'k-')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(H_szabo_KDP));
        hold on
        plot(NNs(indi),mean(AA,2),'bo--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(H_szabo_expF));
        hold on
        plot(NNs(indi),mean(AA,2),'ys:')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(H_szabo_vME));
        hold on
        plot(NNs(indi),mean(AA,2),'m--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(H_szabo_ensemble));
        hold on
        plot(NNs(indi),mean(AA,2),'c:')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        set(gca, 'YScale', 'log')
        
        grid
        axis tight
        iii = iii+1;
end

% PRINT time

alfa = 0.15;
SS = 1;
%for ind_Ns = 1:length(NNs)
for ind_d = 1:length(DDs)
        indi = 1:size(RES,1);
        
        figure
        H_ori = []; H_rbig_nats = []; H_szabo_kNN_k = [];
        H_szabo_KDP = []; H_szabo_expF = []; H_szabo_vME = []; H_szabo_ensemble = [];
        for nnn = 1:5
            H_rbig_nats(:,nnn) = cat(1,RES(indi,ind_d,nnn).t_H_rbig);
            H_szabo_kNN_k(:,nnn) = cat(1,RES(indi,ind_d,nnn).t_H_szabo_kNN_k);
            H_szabo_KDP(:,nnn) = cat(1,RES(indi,ind_d,nnn).t_H_szabo_KDP);
            H_szabo_expF(:,nnn) = cat(1,RES(indi,ind_d,nnn).t_H_szabo_expF);
            H_szabo_vME(:,nnn) = cat(1,RES(indi,ind_d,nnn).t_H_szabo_vME);
            H_szabo_ensemble(:,nnn) = cat(1,RES(indi,ind_d,nnn).t_H_szabo_ensemble);
        end
        
        hold on
        AA = (abs(H_rbig_nats));
        plot(NNs(indi),mean(AA,2),'r--')
        hold on
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'r', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        
        AA = (abs(H_szabo_kNN_k));
        hold on
        plot(NNs(indi),mean(AA,2),'k--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'k', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(H_szabo_KDP));
        hold on
        plot(NNs(indi),mean(AA,2),'b--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'b', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(H_szabo_expF));
        hold on
        plot(NNs(indi),mean(AA,2),'y--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'y', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(H_szabo_vME));
        hold on
        plot(NNs(indi),mean(AA,2),'m--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'m', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        AA = (abs(H_szabo_ensemble));
        hold on
        plot(NNs(indi),mean(AA,2),'c--')
        xx = [NNs(indi) flip(NNs(indi))];
        yy = [mean(AA,2)'+SS*std(AA') flip(mean(AA,2)'-SS*std(AA'))];
        fill(xx,yy,'c', 'LineStyle', 'None', 'FaceAlpha', alfa)
        
        set(gca, 'YScale', 'log')
        
        xlabel('# samples')
        ylabel('computational time (s)')
        
        grid
        axis tight
        print('-deps2c',[print_fold 'FIG_entr_parale_t_DIM_' num2str(DDs(ind_d))])
end


