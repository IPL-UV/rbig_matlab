

clear all
close all

addpath(genpath('/media/disk/vista/Papers/2018_RBIG_IT_measures/'))
addpath(genpath('/media/disk/users/valero/FUMADAS/2017_RBIG/'))

save_data_fold = '/media/disk/vista/Papers/2018_RBIG_IT_measures/reproducible_results/DATA/';
save_res_fold = '/media/disk/vista/Papers/2018_RBIG_IT_measures/reproducible_results/RES/';

%% linear

NNs = [500 1000 5000 10000 30000 50000];
DDs = [2 3 10 50 100];

Nsamples_ori = 500000;

RES(1,1,1).NNs = NNs;
RES(1,1,1).DDs = DDs;

for ind_d = 1:length(DDs) 
    for ind_Ns = 1:length(NNs)
        for ind_tryal = 1:5
            
            Nsamples = NNs(ind_Ns);
            dim_ori = DDs(ind_d);
            
            load([save_data_fold 'TC_lin/DATA_TC_lin_nd_' num2str(dim_ori) '_Ns_' num2str(Nsamples) '_tryal_' num2str(ind_tryal)])
            
            %% ORIGINAL
            
            RES(ind_Ns,ind_d,ind_tryal).TC_ori = TC_ori_nats;
            
            %% SZABO
            if dim_ori<=10
                tic
                RES(ind_Ns,ind_d,ind_tryal).TC_Shannon_AP = muting_val(dat);
                RES(ind_Ns,ind_d,ind_tryal).t_TC_Shannon_AP = toc;
            end
            
            
            tic
            cost_name = 'Shannon_kNN_k';      %d>=1
            co = H_initialization(cost_name,1);
            RES(ind_Ns,ind_d,ind_tryal).TC_szabo_kNN_k = IShannon_HShannon_estimation_val(dat',co);
            RES(ind_Ns,ind_d,ind_tryal).t_TC_szabo_kNN_k = toc;
            
            %             % Shannon_KDP
            tic
            cost_name = 'Shannon_KDP';      %d>=1
            co = H_initialization(cost_name,1);
            RES(ind_Ns,ind_d,ind_tryal).TC_szabo_KDP = IShannon_HShannon_estimation_val(dat',co);
            RES(ind_Ns,ind_d,ind_tryal).t_TC_szabo_KDP = toc;
            
            % Shannon_expF
            tic
            cost_name = 'Shannon_expF';      %d>=1
            co = H_initialization(cost_name,1);
            RES(ind_Ns,ind_d,ind_tryal).TC_szabo_expF = IShannon_HShannon_estimation_val(dat',co);
            RES(ind_Ns,ind_d,ind_tryal).t_TC_szabo_expF = toc;
            
            % Shannon_vME
            tic
            cost_name = 'Shannon_vME';      %d>=1
            co = H_initialization(cost_name,1);
            RES(ind_Ns,ind_d,ind_tryal).TC_szabo_vME = IShannon_HShannon_estimation_val(dat',co);
            RES(ind_Ns,ind_d,ind_tryal).t_TC_szabo_vME = toc;
            
            % ensemble
            tic
            cost_name = 'ensemble';      %d>=1
            co = H_initialization(cost_name,1);
            RES(ind_Ns,ind_d,ind_tryal).TC_szabo_ensemble = IShannon_HShannon_estimation_val(dat',co);
            RES(ind_Ns,ind_d,ind_tryal).t_TC_szabo_ensemble = toc;
            
            %% RBIG
            t1 = cputime;
            
            TC_rbig = RBIG_TC(dat');
            
            RES(ind_Ns,ind_d,ind_tryal).t_rbig = t1-cputime;
            RES(ind_Ns,ind_d,ind_tryal).TC_rbig_nats = TC_rbig*log(2);
            
            %% SAVE
            save([save_res_fold 'RES_TC_lin'],'RES')
        end
        [ind_Ns ind_d]
    end
end

