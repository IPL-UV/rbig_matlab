

clear all
close all

addpath(genpath('/media/disk/vista/Papers/2018_RBIG_IT_measures/'))
addpath(genpath('/media/disk/users/valero/FUMADAS/2017_RBIG/'))

save_data_fold = '/media/disk/vista/Papers/2018_RBIG_IT_measures/reproducible_results/DATA/';

%% t-student
NNs = [500 1000 5000 10000 30000 50000 200000];
DDs = [2 3 5 10 20 50 100];
NUs = [3 5 10 20 100];

RES(1,1,1).NNs = NNs;
RES(1,1,1).DDs = DDs;
RES(1,1,1).NUs = NUs;

for ind_d = 1:length(DDs)
    for ind_nu = 1:length(NUs)
        for ind_Ns = 1:length(NNs)
            
            for ind_tryal = 1:5
                
                Nsamples = NNs(ind_Ns);
                dim_ori = DDs(ind_d);
                nu_ori = NUs(ind_nu);
                
                rand('seed',ind_tryal)
                A = rand(dim_ori);
                A = A*A';
                COV_ori = 10*eye(dim_ori)+A;
                
                
                C_ori = corrcov(COV_ori);
                dat = mvtrnd_val(C_ori, nu_ori, Nsamples,ind_tryal);
                H_ori_nats = mvt_entr_val(size(dat,2),nu_ori,C_ori);
                
                save([save_data_fold 'ENTROPY_tstu/DATA_ENTROPY_tstu_nd_' num2str(dim_ori) '_Ns_' num2str(Nsamples) ...
                    '_tryal_' num2str(ind_tryal) '_nu_' num2str(ind_nu) ]...
                    ,'H_ori_nats','dat')
            end
            [ind_d ind_nu ind_Ns]
        end
    end
end


